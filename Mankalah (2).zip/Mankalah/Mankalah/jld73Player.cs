﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace Mankalah
{
    /*********************************************************/
    /* A Kalah player that uses alpha beta
    /*********************************************************/
    public class Jld73Player : Player {

        Position pos;
        static Stopwatch timer = new Stopwatch();
        static int upper, lower;
        static int timeout;

       /*
        * Initialize the player
        */
        public Jld73Player(Position pos, int timeLimit) : base(pos, "jld73", timeLimit) {
            this.pos = pos;
            timeout = timeLimit;
            if (pos == Position.Top) { // Find bounds for moves.
                upper = 13;
                lower = 7;
            } else {
                upper = 6;
                lower = 0;
            }
        }

        /*
        * Does the top level work of choosing a move
        */
        public override int chooseMove(Board b) {
            timer.Reset();// restart timer
            timer.Start();
            int bestMove = -1;
            try {
                for (int depth = 1; ; depth++) { // Staged DFS
                    int[] ls = new int[14]; // An array to track the best moves
                    for (int i = 0; i < 14; i++) {
                        ls[i] = Int32.MinValue; // Initialize all values to -infinity
                    }
                    for (int i = lower; i < upper; i++) { // Check for all legal moves
                        if (b.legalMove(i)) {
                            Board b2 = new Board(b);
                            b2.makeMove(i, false); // Create a new board representing each move

                            ls[i] = alphabeta(b2, depth, Int32.MinValue, Int32.MaxValue, b2.whoseMove() == pos); // Add the optimal result of each move
                        }
                    }
                    int max = Int32.MinValue; // Initialize max to -infinity
                    int bestMoveTmp = -1; // Initialize the best move to "null"
                    for (int i = 0; i < 14; i++) { // Go through all possible moves
                        if (ls[i] > max) {
                            max = ls[i]; // If the next item is the best yet, update
                            bestMoveTmp = i;
                        }
                    }
                    bestMove = bestMoveTmp; // If the depth manages to finish completely within  the limit, update bestMove
                }

            } catch (Exception) { // If timer is up, this will trigger
                return bestMove; // Return the best move from the most recently completed depth
            }
        }
        /*
        * Does an alpha beta prned minimax search
        */
        public int alphabeta(Board b, int depth, int alpha, int beta, bool max)
        {
            if(timer.ElapsedMilliseconds > timeout - 25) {
                throw new Exception();  // Check the timer at every function call
            }
            if (depth == 0) {
                return evaluate(b, pos == Position.Top); // Base case
            }
            if (max) { // Maximization code
                int v = Int32.MinValue; // Initiallize v to -infinity
                for (int i = 0; i < 14; i++) { // try all possible moves
                    Board b2 = new Board(b);
                    if (b.legalMove(i)) {
                        b2.makeMove(i, false); // Generate a board for each
                    } else {
                        continue;
                    }
                    v = Math.Max(v, alphabeta(b2, depth - 1, alpha, beta, b2.whoseMove() == pos)); // Recurse and store the results
                    alpha = Math.Max(alpha, v); // Update alpha
                    if (beta <= alpha) { // Prune
                        return beta;
                    }
                }
                if (v == Int32.MinValue) {
                    return evaluate(b, pos == Position.Top); // Base case
                }
                return v;
            } else {
                int v = Int32.MaxValue; // Initiallize v to infinity
                for (int i = 0; i < 14; i++) { // try all possible moves
                    Board b2 = new Board(b);
                    if (b.legalMove(i)) {
                        b2.makeMove(i, false);// Generate a board for each
                    } else {
                        continue;
                    }
                    v = Math.Min(v, alphabeta(b2, depth - 1, alpha, beta, b2.whoseMove() == pos)); // Recurse and store the results
                    beta = Math.Min(beta, v); // Update alpha
                    if (beta <= alpha) {
                        return alpha; // Prune
                    }
                }
                if (v == Int32.MaxValue) {
                    return evaluate(b, pos == Position.Top); // Base case
                }
                return v;
            }
        }
        /*
        * Evaluates the board state
        */
        public int evaluate(Board b, bool top)
        {
            // TODO fix
            int score = b.stonesAt(13) - b.stonesAt(6);
            int botb = 0;
            int topb = 0;
            score *= 10;
            for (int i = 0; i < 6; i++) // Figure out how many stones are on each side
                botb += b.board[i];
            for (int i = 7; i < 13; i++)
                topb += b.board[i];
            float weight = (48 - botb - topb) / 4;
            // Weight the importance of hoarding stones based on number of stones remaining.
            return (top) ? (int)(score + (topb * weight) - (botb * weight)) : (int)(-score - (topb * weight) + (botb * weight));
            //return (-score * 10) + topb;
        }









        public override string gloat() {
            return "";
        }

        public int minmax(int depth, Board b)
        {
            if (timer.ElapsedMilliseconds >= 4000) {
                throw new Exception();
            }
            if (depth == 0) { // If maximum depth has been reached, return the evaluate() of 
                return evaluate(b, pos == Position.Top);
            }
            Board[] children = new Board[14];
            bool max = b.whoseMove() == pos; // Check if this is a max or min node
            bool dead = true; // Track if there's a valid move
            // Generate all possible moves
            if (b.whoseMove() == Position.Top) {
                for (int i = 7; i < 12; i++) {
                    if (b.legalMove(i)) {
                        Board child = new Board(b);
                        child.makeMove(i, false);
                        children[i] = child;
                        dead = false;
                    }
                }
            } else {
                for (int i = 0; i < 5; i++) {
                    if (b.legalMove(i)) {
                        Board child = new Board(b);
                        child.makeMove(i, false);
                        children[i] = child;
                        dead = false;
                    }
                }
            }

            if (dead) { // If the game is over, return the score for the game
                return evaluate(b, pos == Position.Top) * 10;
            }
            
            int best = max ? Int32.MinValue : Int32.MaxValue;
            //Console.WriteLine(max + " Children:");
            foreach (Board bd in children) {
                if (bd == null)
                    continue; // Skip empty spots

                int score = minmax(depth - 1, bd);
                //Console.WriteLine("\tScore: " + score);
                if (max && score > best) {
                    best = score;
                } else if (!max && score < best) {
                    best = score;
                }
            }
            //Console.WriteLine("Best Score: " + best);

            return best;

            //int score = max ? Int32.MinValue : Int32.MaxValue;
            //int test;
            //foreach (Board bd in children) {
            //    test = minmax(depth - 1, bd);
            //    if (max && test > score)
            //        score = test;
            //    else if (!max && test < score)
            //        score = test;
            //}
            //return score;
        }

        //public int evaluate(List<Board> children, bool top)
        //{
        //    int ret = 0;
        //    foreach (Board b in children) {
        //        int score = calc(b, )
        //        if (max && n.value > ret)
        //            ret = n.value;
        //        else if (min && n.value < ret)
        //            ret = n.value;
        //    }
        //    return ret;
        //}

        // Return the difference of score for the game
        
    }
}
